document.getElementById('status-form').addEventListener('submit', async function (e) {
    e.preventDefault(); // Prevent the form from submitting the traditional way
    const transactionId = document.getElementById('transaction-id').value;
    
    // Fetch API call to the backend
    try {
        const response = await fetch(`http://localhost:8080/api/transaction/${transactionId}`);
        
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        
        const status = await response.json();
        document.getElementById('status-output').innerText = `Transaction Status: ${status.message}`;
    } catch (error) {
        document.getElementById('status-output').innerText = `Error: ${error.message}`;
    }
});
