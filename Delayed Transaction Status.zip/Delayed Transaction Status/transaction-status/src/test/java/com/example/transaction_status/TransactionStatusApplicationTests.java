package com.example.transaction_status;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Configuration;

@SpringBootTest
public class TransactionStatusApplicationTests {

	@Configuration
	static class TestConfig {
		// Define beans or configurations specific to your test
	}

	@Test
	public void contextLoads() {
		// Your test code here
	}
}

