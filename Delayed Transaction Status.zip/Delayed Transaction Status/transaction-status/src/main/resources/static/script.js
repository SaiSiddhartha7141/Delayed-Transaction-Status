document.getElementById("fetchTransaction").addEventListener("click", async () => {
    const loadingText = document.getElementById("loading");
    const errorText = document.getElementById("error");
    const detailsList = document.getElementById("detailsList");

    loadingText.classList.remove("hidden");
    errorText.classList.add("hidden");
    detailsList.classList.add("hidden");
    detailsList.innerHTML = "";

    try {
        const response = await fetch("http://localhost:8080/api/transaction/11111");
        if (!response.ok) {
            throw new Error("Network response was not ok");
        }
        const transaction = await response.json();

        loadingText.classList.add("hidden");
        detailsList.classList.remove("hidden");

        for (const [key, value] of Object.entries(transaction)) {
            const listItem = document.createElement("li");
            listItem.textContent = `${key}: ${value}`;
            detailsList.appendChild(listItem);
        }
    } catch (error) {
        console.error("Error fetching transaction:", error);
        loadingText.classList.add("hidden");
        errorText.classList.remove("hidden");
    }
});
