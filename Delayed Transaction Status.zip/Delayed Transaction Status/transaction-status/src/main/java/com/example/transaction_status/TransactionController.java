package com.example.transaction_status;
//package com.example.transactionstatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/transaction")
public class TransactionController {

    @Autowired
    private TransactionService transactionService;

    @GetMapping("/{id}")
    public ResponseEntity<Map<String, String>> getTransactionStatus(@PathVariable String id) {
        String status = transactionService.checkTransactionStatus(id);
        Map<String, String> response = new HashMap<>();
        response.put("message", status);
        return ResponseEntity.ok(response);
    }
}



