package com.example.transaction_status;
//package com.example.transactionstatus;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


//public class TransactionService {

    @Service
    public class TransactionService {
        @Autowired
        private TransactionRepository transactionRepository;

        public String checkTransactionStatus(String transactionId) {
            Transaction transaction = transactionRepository.findByTransactionId(transactionId);
            return transaction != null ? transaction.getStatus() : "Transaction Not Found";
        }
    }


