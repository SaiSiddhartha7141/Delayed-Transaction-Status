package com.example.transaction_status;
import org.springframework.data.jpa.repository.JpaRepository;
//public interface TransactionRepository {
//    package com.example.transactionstatus;



    public interface TransactionRepository extends JpaRepository<Transaction, Long> {
        // Custom method to find a transaction by its transactionId
        Transaction findByTransactionId(String transactionId);
    }


