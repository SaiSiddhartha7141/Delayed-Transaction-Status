// package backend;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Answer {

    private int id;
    private String answer, category;

    public Answer(String answer, String category) {
        this.answer = answer;
        this.category = category;
    }

    public Answer() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    // Fetch answer by ID using prepared statement to prevent SQL injection
    public Answer getById(int id) {
        Answer ans = null;
        String query = "SELECT * FROM answer WHERE id = ?"; // Make sure the table name is correct
        try (Connection conn = DBHelper.getConnection(); // Ensure DBHelper is defined
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    ans = new Answer();
                    ans.setId(rs.getInt("id"));
                    ans.setAnswer(rs.getString("answer"));
                    ans.setCategory(rs.getString("category"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Improve error handling/logging here
        }
        return ans;
    }

    // Fetch all answers
    public List<Answer> getAll() {
        List<Answer> listAnswer = new ArrayList<>();
        String query = "SELECT * FROM answer"; // Make sure the table name is correct
        try (Connection conn = DBHelper.getConnection();
             PreparedStatement ps = conn.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Answer ans = new Answer();
                ans.setId(rs.getInt("id"));
                ans.setAnswer(rs.getString("answer"));
                ans.setCategory(rs.getString("category"));
                listAnswer.add(ans);
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Improve error handling/logging here
        }
        return listAnswer;
    }

    // Search for answers by keyword and return a random result
    public String searchAnswer(String keyword) {
        List<Answer> list = this.search(keyword);
        Answer rand = getRandomAnswer(list);
        return rand != null ? rand.getAnswer() : "No answer found";
    }

    // Filter answers by category
    public List<Answer> filterAsk(String keyword) {
        List<Answer> hasilCategory = new ArrayList<>();
        String sqlSearch = "SELECT * FROM answer WHERE category = ?"; // Fixed table and column names
        try (Connection conn = DBHelper.getConnection();
             PreparedStatement ps = conn.prepareStatement(sqlSearch)) {
            ps.setString(1, keyword);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Answer ans = new Answer();
                    ans.setCategory(rs.getString("category"));
                    hasilCategory.add(ans);
                }
            }
        } catch (SQLException e) {
            Answer ans = new Answer();
            ans.setCategory("undefined");
            hasilCategory.add(ans);
        }
        return hasilCategory;
    }

    // Search for answers by category using a keyword
    public List<Answer> search(String keyword) {
        List<Answer> listAnswer = new ArrayList<>();
        String sqlSearch = "SELECT * FROM answer WHERE category LIKE ?";
        try (Connection conn = DBHelper.getConnection();
             PreparedStatement ps = conn.prepareStatement(sqlSearch)) {
            ps.setString(1, "%" + keyword + "%");
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Answer ans = new Answer();
                    ans.setId(rs.getInt("id"));
                    ans.setAnswer(rs.getString("answer"));
                    ans.setCategory(rs.getString("category"));
                    listAnswer.add(ans);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Improve error handling/logging here
        }
        return listAnswer;
    }

    // Get a random answer from the list
    public static Answer getRandomAnswer(List<Answer> answerList) {
        if (answerList.isEmpty()) {
            return null;
        }
        return answerList.get(new Random().nextInt(answerList.size()));
    }

    // Save or update an answer
    public void save() {
        if (getById(id) == null) { // Ensure id is set before this check
            String sqlInsert = "INSERT INTO answer (answer, category) VALUES(?, ?)";
            try (Connection conn = DBHelper.getConnection();
                 PreparedStatement ps = conn.prepareStatement(sqlInsert, PreparedStatement.RETURN_GENERATED_KEYS)) {
                ps.setString(1, this.answer);
                ps.setString(2, this.category);
                ps.executeUpdate();
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    if (rs.next()) {
                        this.id = rs.getInt(1);
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace(); // Improve error handling/logging here
            }
        } else {
            String sqlUpdate = "UPDATE answer SET answer = ?, category = ? WHERE id = ?";
            try (Connection conn = DBHelper.getConnection();
                 PreparedStatement ps = conn.prepareStatement(sqlUpdate)) {
                ps.setString(1, this.answer);
                ps.setString(2, this.category);
                ps.setInt(3, this.id);
                ps.executeUpdate();
            } catch (SQLException e) {
                e.printStackTrace(); // Improve error handling/logging here
            }
        }
    }

    // Delete an answer by ID
    public void delete() {
        String sqlDelete = "DELETE FROM answer WHERE id = ?";
        try (Connection conn = DBHelper.getConnection();
             PreparedStatement ps = conn.prepareStatement(sqlDelete)) {
            ps.setInt(1, this.id);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace(); // Improve error handling/logging here
        }
    }
}
